# JKSSB JE Mechanical — phone app

31,393 previous-year questions, high-yield practice and negative-marked mocks. Works fully offline.

## Put it on GitHub (once, about 10 minutes, from a computer)
1. Sign in at github.com and create a new **public** repository, e.g. `jkssb-je-mech`.
2. On the repository page choose **Add file → Upload files** and drag in everything from this folder
   (the `www` folder, `package.json`, `capacitor.config.json`, `README.md` and the `.github` folder).
   Click **Commit changes**.
   - If the `.github` folder does not upload (hidden folders are skipped on some computers), choose
     **Add file → Create new file**, type the name `.github/workflows/build.yml`, paste the contents of that file, and commit.
3. Open **Settings → Pages** and set **Source** to **GitHub Actions**.
4. Open the **Actions** tab. The "Build app" run takes about 5 minutes. (If it did not start, click **Build app → Run workflow**.)

## Install on your phone
**Any phone (iPhone or Android) — installable web app**
- When the run finishes, your address is `https://<your-username>.github.io/jkssb-je-mech/`.
- Android (Chrome): open it → menu ⋮ → **Install app**. iPhone (Safari): open it → Share → **Add to Home Screen**.
- Open it once while online; after that it works with no internet.

**Android only — real installer (APK)**
- Actions tab → the latest green run → **Artifacts** → download **JKSSB-JE-Mech-APK** (a .zip containing `JKSSB-JE-Mech.apk`).
- Copy the .apk to your phone, tap it, and allow "Install unknown apps" for your file manager when asked.

## Notes
- Progress is saved on the phone (in the app's storage). The "Explain with Claude" and "Report a problem" buttons
  and account sync only exist in the Claude version of the app, so they are hidden here.
- To update the questions later, replace the files in `www` with a newer version and commit; both builds rerun.
