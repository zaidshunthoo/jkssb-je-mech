/* ===== Questions by exam ===== */
(function(){
if(!window.EXIDX)return;
const BYID=new Map(ALLQ.map(q=>[q.id,q]));
const get=ids=>ids.map(i=>BYID.get(i)).filter(Boolean);
let timed=false,filter='';
function launch(ids,label){const qs=get(ids);if(!qs.length)return note('No questions here.');if(timed){const n=Math.min(qs.length,120);startQueue(shuffle(qs).slice(0,n),label,true,n)}else startQueue(shuffle(qs),label,false)}
function seenOf(ids){const p=getProgress();let s=0;for(const i of ids)if(p[i])s++;return s}
function examList(){stopTimer();state.mode='exams';const O=EXIDX.orgs.filter(o=>!filter||o.n.toLowerCase().includes(filter));
 app.innerHTML=`<div class='wrap'><div class='row'><button class='btn secondary' id='ex-home'>← Home</button><span class='pill'>${EXIDX.orgs.length} exam bodies</span></div><h1>Questions by exam</h1>
 <p class='muted'>Every question tagged with the exam it was asked in. One question can belong to several exams.</p>
 <div class='row' style='justify-content:flex-start;gap:12px;margin:8px 0'><input id='ex-q' type='search' placeholder='Search exam, e.g. SSC, TSPSC, ISRO' value="${esc(filter)}" style='flex:1;min-width:200px;font:inherit;padding:10px 12px;border:1px solid var(--line);border-radius:9px;background:var(--surface);color:var(--ink)'><label class='small' style='display:flex;align-items:center;gap:6px'><input type='checkbox' id='ex-t' ${timed?'checked':''}> Timed test (up to 120 Q)</label></div>
 <div class='grid'>${O.map((o,i)=>{const all=[...new Set(o.posts.flatMap(p=>p.y.flatMap(y=>y[1])))];return `<button class='card subject' data-o='${EXIDX.orgs.indexOf(o)}'><b>${esc(o.n)}</b><span class='muted'>${o.c.toLocaleString()} questions · ${o.posts.map(p=>p.p).filter(Boolean).slice(0,4).join(', ')||'all posts'} · ${seenOf(all)} seen</span></button>`}).join('')}</div>
 <h2>From books (no exam tag)</h2><div class='grid'>${EXIDX.books.map((b,i)=>`<button class='card subject' data-b='${i}'><b>${esc(b.n)}</b><span class='muted'>${b.ids.length} questions · ${seenOf(b.ids)} seen</span></button>`).join('')}</div></div>`;
 document.querySelector('#ex-home').onclick=home;
 const qi=document.querySelector('#ex-q');qi.oninput=()=>{filter=qi.value.trim().toLowerCase();const pos=qi.selectionStart;examList();const n=document.querySelector('#ex-q');n.focus();n.setSelectionRange(pos,pos)};
 document.querySelector('#ex-t').onchange=e=>{timed=e.target.checked};
 document.querySelectorAll('[data-o]').forEach(b=>b.onclick=()=>examPage(EXIDX.orgs[+b.dataset.o]));
 document.querySelectorAll('[data-b]').forEach(b=>b.onclick=()=>{const x=EXIDX.books[+b.dataset.b];launch(x.ids,x.n)})}
function examPage(o){stopTimer();state.mode='exams';const all=[...new Set(o.posts.flatMap(p=>p.y.flatMap(y=>y[1])))];
 app.innerHTML=`<div class='wrap'><div class='row'><button class='btn secondary' id='ex-back'>← All exams</button><span class='pill'>${o.c.toLocaleString()} questions</span></div><h1>${esc(o.n)}</h1>
 <div class='toolbar'><button class='btn' id='ex-all'>Practise all ${o.c.toLocaleString()}</button><label class='small' style='display:flex;align-items:center;gap:6px'><input type='checkbox' id='ex-t' ${timed?'checked':''}> Timed test (up to 120 Q)</label></div>
 ${o.posts.map((p,pi)=>{const ids=[...new Set(p.y.flatMap(y=>y[1]))];return `<div class='card' style='margin:10px 0'><div class='row'><h3 style='margin:0'>${esc(p.p||o.n)}</h3><button class='btn secondary' data-p='${pi}' style='min-height:36px;padding:6px 12px'>All ${ids.length}</button></div>
  <div class='toolbar' style='margin:10px 0 0'>${p.y.map((y,yi)=>`<button class='btn secondary qjump' data-p='${pi}' data-y='${yi}' style='min-width:auto;padding:6px 10px'>${esc(y[0])} <span class='hy-sub'>${y[1].length}</span></button>`).join('')}</div></div>`}).join('')}</div>`;
 document.querySelector('#ex-back').onclick=examList;document.querySelector('#ex-t').onchange=e=>{timed=e.target.checked};
 document.querySelector('#ex-all').onclick=()=>launch(all,o.n);
 document.querySelectorAll('[data-p]').forEach(b=>b.onclick=()=>{const p=o.posts[+b.dataset.p];if(b.dataset.y!=null){const y=p.y[+b.dataset.y];launch(y[1],`${o.n} ${p.p} ${y[0]}`.replace(/\s+/g,' '))}else launch([...new Set(p.y.flatMap(y=>y[1]))],`${o.n} ${p.p}`)})}
window.examList=examList;
const _home=home;home=function(){_home();try{const pt=document.querySelector('.primary-tools');if(pt&&!document.querySelector('#bye')){pt.insertAdjacentHTML('beforeend',`<button class='btn secondary hy-btn' id='bye'>Questions by exam <span class='hy-sub'>SSC JE, RRB JE, TSPSC, ISRO, state PSCs… by year</span></button>`);document.querySelector('#bye').onclick=()=>{filter='';examList()}}}catch(e){console.error(e)}};
if(state.mode==='home')home();
})();
