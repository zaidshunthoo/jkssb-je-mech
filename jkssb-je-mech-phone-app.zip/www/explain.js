/* ===== AI explanations (online, on demand) ===== */
(function(){
const LSG=(k,d)=>{try{const v=localStorage.getItem(k);return v==null?d:JSON.parse(v)}catch(e){return d}};
const LSS=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
const css=`.ai-row{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}.ai-btn{min-height:38px;padding:6px 12px}.ai-box{margin-top:10px;padding:12px 14px;border:1px solid var(--line);border-radius:10px;background:var(--surface);line-height:1.55}.ai-box ul{margin:6px 0;padding-left:20px}.ai-box .ai-h{font-size:12px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;opacity:.65;margin-bottom:6px;display:flex;justify-content:space-between;gap:8px}.ai-q{border-top:1px dashed var(--line);margin-top:10px;padding-top:8px}.ai-ask{display:flex;gap:8px;margin-top:10px}.ai-ask input{flex:1;min-width:0;font:inherit;padding:8px 10px;border:1px solid var(--line);border-radius:8px;background:var(--paper);color:var(--ink)}.ai-set label{display:flex;flex-direction:column;gap:6px;font-weight:600;margin:10px 0}.ai-set input,.ai-set select{font:inherit;padding:9px 10px;border:1px solid var(--line);border-radius:8px;background:var(--surface);color:var(--ink)}.ai-warn{color:#b3261e}`;
const st=document.createElement('style');st.textContent=css;document.head.appendChild(st);

/* ---------- providers ---------- */
let SAMPLE=null;            // Claude (only inside the Claude app version)
if(window.claude&&claude.use)claude.use('sample').then(s=>{SAMPLE=s;refresh()}).catch(()=>{});
const cfg=()=>LSG('jkssb-ai-cfg',{p:'',key:'',model:''});
function provider(){if(SAMPLE)return 'claude';const c=cfg();return c.key&&(c.p==='gemini'||c.p==='anthropic')?c.p:''}
const GEM=['gemini-flash-latest','gemini-3.5-flash-lite','gemini-2.5-flash','gemini-2.0-flash'];
async function gemini(turns,signal,onText){const c=cfg();const models=c.model?[c.model]:(c.am?[c.am,...GEM.filter(x=>x!==c.am)]:GEM);let last;
 for(const m of models){const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(m)}:generateContent`,{method:'POST',signal,headers:{'Content-Type':'application/json','x-goog-api-key':c.key},body:JSON.stringify({contents:turns.map(t=>({role:t.role==='assistant'?'model':'user',parts:[{text:t.content}]})),generationConfig:{temperature:0.3,maxOutputTokens:2048}})});
  const j=await r.json().catch(()=>({}));
  if(r.ok){const t=(j.candidates&&j.candidates[0]&&j.candidates[0].content&&j.candidates[0].content.parts||[]).map(p=>p.text||'').join('').trim();if(!t)throw{code:'empty',message:'Gemini sent an empty answer. Try again.'};if(!c.model&&c.am!==m)LSS('jkssb-ai-cfg',{...c,am:m});onText(t);return t}
  last={code:r.status,message:(j.error&&j.error.message)||('Gemini error '+r.status)};if(r.status!==404&&r.status!==400)break}
 if(last&&(last.code===400||last.code===403)&&/key/i.test(last.message))last.message='Gemini says the API key is not valid. Check it in AI settings.';
 if(last&&last.code===429)last.message='Gemini free limit reached for now. Wait a minute (or until tomorrow) and try again.';
 throw last}
async function anthropic(turns,signal,onText){const c=cfg();const r=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',signal,headers:{'content-type':'application/json','x-api-key':c.key,'anthropic-version':'2023-06-01','anthropic-dangerous-direct-browser-access':'true'},body:JSON.stringify({model:c.model||'claude-haiku-4-5-20251001',max_tokens:1200,messages:turns})});
 const j=await r.json().catch(()=>({}));if(!r.ok)throw{code:r.status,message:r.status===401?'Anthropic says the API key is not valid. Check it in AI settings.':((j.error&&j.error.message)||('Anthropic error '+r.status))};
 const t=(j.content||[]).map(b=>b.text||'').join('').trim();onText(t);return t}
async function ask(turns,signal,onText){const p=provider();
 if(p==='claude'){const r=await SAMPLE(turns,{signal,cache:false,onText:({text})=>onText(text)});return r.text}
 if(!navigator.onLine)throw{code:'offline',message:"You're offline. Explanations need internet."};
 if(p==='gemini')return gemini(turns,signal,onText);if(p==='anthropic')return anthropic(turns,signal,onText);
 throw{code:'setup',message:'Set up AI explanations first.'}}

/* ---------- prompt ---------- */
function prompt(q,picked){const notes=(window.getNotes&&getNotes()[q.id])||{};const ans=q.opts[q.ans-1];
 return `You are a tutor for the JKSSB Junior Engineer (Mechanical) exam in India (diploma level). Explain this multiple-choice question to a student.

Subject: ${q.subject} — ${q.topic}
Question: ${q.q}
Options:
${q.opts.map(o=>'- '+o).join('\n')}
Answer marked in the app: ${ans}
${q.exp&&!/^Correct answer/i.test(q.exp)?'Explanation already in the app: '+q.exp+'\n':''}${q.fix?'Correction note in the app: '+q.fix+'\n':''}${notes.n?"Student's own note: "+notes.n+'\n':''}${picked&&picked!==q.ans?'The student chose: '+q.opts[picked-1]+'\n':''}
How to answer:
1. First check the marked answer. If you are confident it is wrong, start with one line: "⚠ The marked answer looks wrong — the correct answer is <option text>" and give the reason. If the question is ambiguous or has a printing error, say so briefly.
2. Explain why the correct answer is right in 3–6 short lines: the concept, any formula with its symbols defined, and for numericals the full working with units.
${picked&&picked!==q.ans?"3. Say in one line why the student's choice is wrong.\n":'3. One short line on why each other option is wrong (skip any that are obvious).\n'}4. End with one line starting "Tip:" — a way to remember it.
Refer to options by their text, never by letter (the app shuffles letters). Keep it under 220 words. Plain text: **bold** for key terms, lines starting "- " for bullets, no headings, no tables, no LaTeX (write formulas like P = 2πNT/60).`}

/* ---------- rendering ---------- */
function md(t){return esc(t).replace(/\*\*(.+?)\*\*/g,'<b>$1</b>').split('\n').reduce((a,l)=>{const m=l.match(/^\s*[-•*]\s+(.*)/);if(m){if(!a.ul){a.h+='<ul>';a.ul=1}a.h+='<li>'+m[1]+'</li>'}else{if(a.ul){a.h+='</ul>';a.ul=0}a.h+=l.trim()?'<div>'+l.replace(/^(⚠.*)$/,"<b class='ai-warn'>$1</b>")+'</div>':'<div style="height:6px"></div>'}return a},{h:'',ul:0}).h}
const CACHE=()=>LSG('jkssb-ai',{});
function saveCache(id,v){const c=CACHE();c[id]=v;const ks=Object.keys(c);if(ks.length>1500){ks.sort((a,b)=>c[a].at-c[b].at).slice(0,ks.length-1500).forEach(k=>delete c[k])}LSS('jkssb-ai',c)}
const label={claude:'Claude',gemini:'Gemini',anthropic:'Claude API'};

function mount(host,q,picked,rerender){if(!host||host.querySelector('.ai-row'))return;
 const p=provider(),cached=CACHE()[q.id];
 host.insertAdjacentHTML('beforeend',`<div class='ai-row'><button class='btn secondary ai-btn ai-go'>${cached?'Show AI explanation':'✨ Explain with AI'}</button>${!p?`<span class='muted small' style='align-self:center'>needs internet · <a href='#' class='ai-setup'>set up</a></span>`:''}</div><div class='ai-out'></div>`);
 const out=host.querySelector('.ai-out'),go=host.querySelector('.ai-go');
 const su=host.querySelector('.ai-setup');if(su)su.onclick=e=>{e.preventDefault();settings()};
 let ctl=null,conv=cached?cached.c:null;
 function show(turns,busy){const ai=[];for(let i=1;i<turns.length;i+=2){ai.push({q:i>1?turns[i-1].content:null,a:turns[i]&&turns[i].content})}
  out.innerHTML=`<div class='ai-box'><div class='ai-h'><span>AI explanation · ${label[provider()]||'AI'}</span>${busy?`<button class='bt-link ai-stop' style='background:none;border:0;color:inherit;cursor:pointer;font:inherit;text-decoration:underline'>Stop</button>`:''}</div>${ai.map((x,i)=>`${x.q?`<div class='ai-q'><b>You:</b> ${esc(x.q)}</div>`:''}<div class='ai-a'>${x.a?md(x.a):'<span class="muted">Thinking…</span>'}</div>`).join('')}
  ${busy?'':`<div class='ai-ask'><input placeholder='Ask a follow-up (e.g. derive the formula)' maxlength='400'><button class='btn secondary ai-btn ai-send'>Ask</button></div><div class='ai-row'><button class='btn secondary ai-btn ai-save'>Save to my note</button><button class='btn secondary ai-btn ai-again'>Explain again</button><button class='btn secondary ai-btn ai-hide'>Hide</button></div>`}</div>`;
  const sp=out.querySelector('.ai-stop');if(sp)sp.onclick=()=>ctl&&ctl.abort();
  if(busy)return;
  const inp=out.querySelector('.ai-ask input'),send=()=>{const v=inp.value.trim();if(v)run([...conv,{role:'user',content:v+'\n\n(Answer briefly, same plain-text style.)'}],v)};
  out.querySelector('.ai-send').onclick=send;inp.onkeydown=e=>{if(e.key==='Enter')send()};
  out.querySelector('.ai-again').onclick=()=>run([{role:'user',content:prompt(q,picked)}]);
  out.querySelector('.ai-hide').onclick=()=>{out.innerHTML=''};
  out.querySelector('.ai-save').onclick=()=>{if(!window.setNote)return note('Notes are not available.');const txt=conv.filter(t=>t.role==='assistant').map(t=>t.content).join('\n\n').replace(/\*\*/g,'');const cur=(getNotes()[q.id]||{}).n||'';setNote(q,{n:((cur?cur+'\n\n':'')+'AI: '+txt).slice(0,2000)});note('Saved to your note for this question.');rerender&&rerender()}}
 // display: follow-ups are stored with a clean question text
 function view(turns){return turns.map((t,i)=>i>0&&t.role==='user'?{...t,content:t.content.replace(/\n\n\(Answer briefly[^)]*\)$/,'')}:t)}
 async function run(turns){if(!provider()){settings();return}
  ctl=new AbortController();go.disabled=true;let partial='';
  show(view([...turns,{role:'assistant',content:''}]),true);
  try{const t=await ask(turns,ctl.signal,txt=>{partial=txt;show(view([...turns,{role:'assistant',content:txt}]),true)});
   conv=[...turns,{role:'assistant',content:t}];saveCache(q.id,{c:conv,at:Date.now()});show(view(conv),false)}
  catch(e){const code=e&&(e.code||e.name);if(code==='not_granted'||code==='sampling_disabled'){SAMPLE=null}
   if(code==='cancelled'||code==='AbortError'){if(conv)show(view(conv),false);else out.innerHTML='';}
   else{out.innerHTML=`<div class='ai-box'><b>Couldn't get an explanation.</b><p class='small'>${esc(code==='rate_limited'?'Too many requests or usage limit reached. Try again in a while.':code==='not_granted'?'Claude access was not allowed for this page.':(e&&e.message)||'Network problem. Check your internet and try again.')}</p>${code==='setup'||/key/i.test((e&&e.message)||'')?"<button class='btn secondary ai-btn ai-s2'>AI settings</button>":''}</div>`;const s2=out.querySelector('.ai-s2');if(s2)s2.onclick=settings}}
  finally{go.disabled=false}}
 go.onclick=()=>{if(conv&&!out.innerHTML.trim()){show(view(conv),false);return}if(conv)return;run([{role:'user',content:prompt(q,picked)}])}}

/* ---------- settings page ---------- */
function settings(){stopTimer();const prev={...state};const c=cfg();const inClaude=!!SAMPLE;
 const ret=()=>{if(prev.mode==='quiz'){state=prev;renderQ()}else if(prev.mode==='review'||prev.mode==='summary'){state=prev;review()}else home()};
 app.innerHTML=`<div class='wrap ai-set'><div class='row'><button class='btn secondary' id='ai-back'>← Back</button><span class='pill'>AI explanations</span></div><h1>AI explanations</h1>
 <p class='muted'>Everything else in the app works offline. When you're online, the <b>✨ Explain with AI</b> button under an answer asks an AI to explain it, check the marked answer and take follow-up questions. Explanations you've opened are saved on this device, so you can read them again offline.</p>
 ${inClaude?`<div class='card'><b>✓ Ready</b><p class='small'>This copy runs inside Claude, so it uses your Claude account. No setup needed. The first time, Claude asks you to allow it.</p></div>`:''}
 <div class='card'><h3 style='margin-top:0'>${inClaude?'For the phone/laptop app':'Connect an AI'}</h3>
 <p class='small muted'>The installed app can't use your Claude subscription, so it needs an API key. The key stays only on this device: it isn't synced and isn't in your GitHub repo.</p>
 <label>Service<select id='ai-p'><option value='gemini' ${c.p!=='anthropic'?'selected':''}>Google Gemini (free tier)</option><option value='anthropic' ${c.p==='anthropic'?'selected':''}>Anthropic Claude API (paid, very cheap per question)</option></select></label>
 <div id='ai-help' class='small'></div>
 <label>API key<input id='ai-k' type='password' autocomplete='off' placeholder='Paste your key' value="${esc(c.key||'')}"></label>
 <details class='small'><summary>Advanced: model name</summary><label>Model (leave empty for the default)<input id='ai-m' value="${esc(c.model||'')}" placeholder='default'></label></details>
 <div class='ai-row'><button class='btn' id='ai-save'>Save & test</button>${c.key?"<button class='btn secondary' id='ai-del'>Remove key</button>":''}</div><div id='ai-res' class='small' style='margin-top:8px'></div></div>
 <p class='muted small'>${Object.keys(CACHE()).length} explanations saved on this device.</p></div>`;
 const help=()=>{document.querySelector('#ai-help').innerHTML=document.querySelector('#ai-p').value==='gemini'?`<ol style='padding-left:18px;margin:4px 0'><li>Open <a href='https://aistudio.google.com/apikey' target='_blank' rel='noopener'>aistudio.google.com/apikey</a> and sign in with Google.</li><li>Tap <b>Create API key</b> and copy it.</li><li>Paste it below. The free tier covers normal study use. If you hit the daily limit, wait until the next day.</li></ol>`:`<ol style='padding-left:18px;margin:4px 0'><li>Open <a href='https://console.anthropic.com/settings/keys' target='_blank' rel='noopener'>console.anthropic.com</a>, add a little credit, and create a key.</li><li>Paste it below. Each explanation costs a fraction of a rupee with the default Haiku model.</li></ol>`};
 document.querySelector('#ai-p').onchange=help;help();
 document.querySelector('#ai-back').onclick=ret;
 const del=document.querySelector('#ai-del');if(del)del.onclick=()=>{LSS('jkssb-ai-cfg',{p:'',key:'',model:''});note('Key removed from this device.');settings()};
 document.querySelector('#ai-save').onclick=async()=>{const nc={p:document.querySelector('#ai-p').value,key:document.querySelector('#ai-k').value.trim(),model:document.querySelector('#ai-m').value.trim()};const res=document.querySelector('#ai-res');if(!nc.key){res.textContent='Paste a key first.';return}
  LSS('jkssb-ai-cfg',nc);res.textContent='Testing…';const keep=SAMPLE;SAMPLE=null;
  try{const t=await ask([{role:'user',content:'Reply with exactly: OK'}],undefined,()=>{});res.innerHTML="<b>✓ Working.</b> The Explain button is ready."+(keep?'':'')}catch(e){res.innerHTML="<span class='ai-warn'><b>Didn't work:</b> "+esc((e&&e.message)||'network error')+'</span>'}finally{SAMPLE=keep}}}
window.aiSettings=settings;

/* ---------- hooks ---------- */
const _rq=renderQ;renderQ=function(){_rq();try{const q=state.queue&&state.queue[state.idx];const a=document.querySelector('.quiz .answer');if(q&&a&&state.mode==='quiz')mount(a,q,state.answers[q.id]||state.selected,()=>renderQ())}catch(e){console.error(e)}};
const _rv=review;review=function(){_rv();try{document.querySelectorAll('.card.review').forEach((el,i)=>{const q=state.queue[i];mount(el,q,state.answers[q.id],()=>{const y=scrollY;review();scrollTo(0,y)})})}catch(e){console.error(e)}};
const _h=home;home=function(){_h();try{const tb=document.querySelector('.study-tools .toolbar');if(tb&&!document.querySelector('#aiset')){tb.insertAdjacentHTML('beforeend',"<button class='btn secondary' id='aiset'>AI explanations</button>");document.querySelector('#aiset').onclick=settings}}catch(e){console.error(e)}};
function refresh(){if(state.mode==='home')home()}
if(state.mode==='home')home();
})();
