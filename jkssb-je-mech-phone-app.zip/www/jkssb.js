/* ===== JKSSB Exact: syllabus map, real papers, PYQs, JKSSB-level lookalikes ===== */
(function(){
if(!window.JKMAP)return;
const BYID=new Map(ALLQ.map(q=>[q.id,q]));
const PAPERS=[{k:'2023',name:'JKSSB JE 2023',sub:'01 Oct 2023 · newest pattern (match, statements)'},{k:'2021-1',name:'JKSSB JE 2021 · Paper 1',sub:'2021'},{k:'2021-2',name:'JKSSB JE 2021 · Paper 2',sub:'2021'},{k:'2015',name:'JKSSB JE 2015',sub:'older pattern · 150 questions'}];
const TAG={};for(const q of ALLQ)for(const t of (q.jk||[]))TAG[t]=q;
const paperQs=k=>Object.keys(TAG).filter(t=>t.split(':')[0]===k).sort((a,b)=>+a.split(':')[1]-+b.split(':')[1]).map(t=>TAG[t]);
const PYQ=ALLQ.filter(q=>q.jk&&q.jk.length);
isJKSSB=q=>!!(q.jk&&q.jk.length)||/JKSSB/i.test(q.source||'');
const look=pids=>{const s=new Set(pids);return ALLQ.filter(q=>q.jp&&q.jp.some(p=>s.has(p)))};
const SAME=ALLQ.filter(q=>q.jl==='s'),NEAR=ALLQ.filter(q=>q.jl==='n');
const yrs=qs=>[...new Set(qs.map(t=>t.split(':')[0].replace(/-\d/,'')))];
const PRI={must:['Must-do','h1'],high:['High','h2'],medium:['Medium','h0'],light:['Light','h3']};
function areaQs(a){const pids=[];for(const c of a.concepts)for(const t of c.qs){const q=TAG[t];if(q)pids.push(q.id)}return{pyq:[...new Set(pids)].map(i=>BYID.get(i)),look:look(pids)}}
function back(fn,label){return `<div class='row'><button class='btn secondary' id='jk-back'>← ${label}</button><span class='pill'>JKSSB Exact</span></div>`}

function jkHome(){stopTimer();state.mode='jk';const M=JKMAP,p=getProgress();
 const seen=PYQ.filter(q=>p[q.id]).length,cnt=k=>paperQs(k).length;
 app.innerHTML=`<div class='wrap'>${back(0,'Home')}<h1>JKSSB Exact</h1><p class='muted'>Built only from the official syllabus and the ${PYQ.length} questions JKSSB actually asked (2015, 2021 ×2, 2023). Use it to study exactly what JKSSB tests, at the depth it tests it.</p>
 <div class='card'><h3 style='margin-top:0'>Real JKSSB papers</h3><p class='muted small'>Full timed papers in the original order, negative marking ¼. ${seen} of ${PYQ.length} PYQs attempted.</p><div class='toolbar' style='margin:8px 0 0'>${PAPERS.map(x=>`<button class='btn' data-paper='${x.k}'>${x.name}<span class='hy-sub' style='display:block'>${cnt(x.k)} Q · ${cnt(x.k)} min</span></button>`).join('')}</div>
 <div class='toolbar'><button class='btn secondary' id='jk-allpyq'>All PYQs by chapter</button><button class='btn secondary' id='jk-pyqmix'>Random 30 PYQs</button></div></div>
 <div class='card' style='margin-top:10px'><h3 style='margin-top:0'>JKSSB-level practice</h3><p class='muted small'>${SAME.length} questions that test the same idea as a JKSSB PYQ, and ${NEAR.length} on closely related ideas at the same depth. Nothing harder than JKSSB asks.</p><div class='toolbar' style='margin:8px 0 0'><button class='btn' id='jk-same'>Same-idea practice (30)</button><button class='btn secondary' id='jk-near'>Related-idea practice (30)</button><button class='btn secondary' id='jk-mock'>JKSSB-level mock · 120 Q</button></div></div>
 <h2>Syllabus map</h2><p class='muted small'>${esc(M.trend||'')}</p>
 ${M.units.map((u,ui)=>{const all=u.areas.flatMap(a=>a.concepts.flatMap(c=>c.qs));return `<details class='card study-tools jk-unit'><summary><b>${esc(u.unit)}</b> <span class='muted small'>· ${u.marks} marks · ${all.length} PYQs · ${u.areas.length} areas</span></summary><div style='padding:0 16px 14px'><p class='muted small'>${esc(u.summary||'')}</p>
  ${u.areas.map((a,ai)=>{const pr=PRI[a.priority]||PRI.medium;const n=a.concepts.reduce((s,c)=>s+c.qs.length,0);const ys=yrs(a.concepts.flatMap(c=>c.qs));return `<div class='jk-area'><div class='row'><div><b>${esc(a.area)}</b> <span class='key ${pr[1]}'>${pr[0]}</span>${a.status==='beyond'?" <span class='tag'>Beyond syllabus</span>":''}</div><button class='btn secondary jk-go' data-u='${ui}' data-a='${ai}' ${n?'':'disabled'}>Practise</button></div>
   <p class='muted small' style='margin:4px 0'>${esc(a.why||'')}${ys.length?' · asked: '+ys.join(', '):''}</p>
   ${a.concepts.length?`<ul class='jk-c'>${a.concepts.map(c=>`<li>${esc(c.concept)} <span class='muted small'>(${c.qs.length})</span>${c.note?`<br><span class='muted small'>${esc(c.note)}</span>`:''}</li>`).join('')}</ul>`:''}</div>`}).join('')}</div></details>`}).join('')}
 <h2>What to go light on</h2><div class='card'>${(M.never_asked||[]).length?`<p><b>In the syllabus but never asked so far</b></p><ul>${M.never_asked.map(x=>`<li>${esc(x.syllabus_item)} <span class='muted small'>— ${esc(x.unit)}${x.advice?'. '+esc(x.advice):''}</span></li>`).join('')}</ul>`:''}
 ${(M.skip_advice||[]).length?`<p><b>Above JKSSB level — safe to skip</b></p><ul>${M.skip_advice.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:''}
 ${M.beyond_syllabus_pattern?`<p><b>Beyond the printed syllabus, but asked</b></p><p class='small'>${esc(M.beyond_syllabus_pattern)}</p>`:''}</div></div>`;
 document.querySelector('#jk-back').onclick=home;
 document.querySelectorAll('[data-paper]').forEach(b=>b.onclick=()=>{const qs=paperQs(b.dataset.paper);startQueue(qs,PAPERS.find(x=>x.k===b.dataset.paper).name,true,qs.length)});
 document.querySelector('#jk-allpyq').onclick=pyqByChapter;
 document.querySelector('#jk-pyqmix').onclick=()=>startQueue(shuffle(PYQ).slice(0,30),'JKSSB PYQs · mixed',false);
 document.querySelector('#jk-same').onclick=()=>startQueue(shuffle(SAME).slice(0,30),'JKSSB-level · same idea',false);
 document.querySelector('#jk-near').onclick=()=>startQueue(shuffle(NEAR).slice(0,30),'JKSSB-level · related ideas',false);
 document.querySelector('#jk-mock').onclick=jkMock;
 document.querySelectorAll('.jk-go').forEach(b=>b.onclick=()=>{const a=M.units[+b.dataset.u].areas[+b.dataset.a];areaPage(a,M.units[+b.dataset.u].unit)})}
function areaPage(a,unit){stopTimer();state.mode='jk';const {pyq,look:lk}=areaQs(a);const same=lk.filter(q=>q.jl==='s'),near=lk.filter(q=>q.jl==='n');
 app.innerHTML=`<div class='wrap'>${back(0,'JKSSB Exact')}<p class='muted small' style='margin:10px 0 0'>${esc(unit)}</p><h1>${esc(a.area)}</h1><p class='muted'>${esc(a.why||'')}</p>
 <div class='toolbar primary-tools'><button class='btn' id='a-pyq'>JKSSB PYQs <span class='hy-sub'>${pyq.length}</span></button><button class='btn' id='a-same'>Same idea <span class='hy-sub'>${same.length}</span></button><button class='btn secondary' id='a-near'>Related <span class='hy-sub'>${near.length}</span></button><button class='btn secondary' id='a-all'>All together <span class='hy-sub'>${pyq.length+lk.length}</span></button></div>
 <ul class='jk-c'>${a.concepts.map(c=>`<li><b>${esc(c.concept)}</b> <span class='muted small'>${c.qs.join(' · ')}</span>${c.note?`<br><span class='muted small'>${esc(c.note)}</span>`:''}</li>`).join('')}</ul></div>`;
 document.querySelector('#jk-back').onclick=jkHome;
 const go=(qs,l)=>{if(!qs.length)return note('Nothing here yet.');startQueue(qs,a.area+' · '+l,false)};
 document.querySelector('#a-pyq').onclick=()=>go(pyq,'PYQs');document.querySelector('#a-same').onclick=()=>go(shuffle(same),'same idea');
 document.querySelector('#a-near').onclick=()=>go(shuffle(near),'related');document.querySelector('#a-all').onclick=()=>go([...pyq,...shuffle(lk)],'all')}
function pyqByChapter(){stopTimer();state.mode='jk';const subs=[...new Set(PYQ.map(q=>q.subject))];
 app.innerHTML=`<div class='wrap'>${back(0,'JKSSB Exact')}<h1>All JKSSB PYQs</h1>${subs.map(s=>{const qs=PYQ.filter(q=>q.subject===s);const ts=[...new Set(qs.map(q=>q.topic))];return `<h2>${esc(s)} <span class='muted small'>· ${qs.length}</span></h2><div class='heat'>${ts.map(t=>{const tq=qs.filter(q=>q.topic===t);const p=getProgress();let a=0,c=0;for(const q of tq){const r=p[q.id];if(r){a+=r.attempts||1;c+=r.correct||0}}const acc=a?c/a*100:null;return `<button class='hc ${acc==null?'h0':acc<50?'h1':acc<70?'h2':'h3'}' data-s="${esc(s)}" data-t="${esc(t)}"><span>${esc(t)}</span><b>${tq.length}</b><small>PYQs</small></button>`}).join('')}</div>`}).join('')}</div>`;
 document.querySelector('#jk-back').onclick=jkHome;
 document.querySelectorAll('.hc').forEach(x=>x.onclick=()=>startQueue(PYQ.filter(q=>q.subject===x.dataset.s&&q.topic===x.dataset.t),'JKSSB PYQs · '+x.dataset.t,false))}
function jkMock(){const W={'Theory of Machines and Machine Design':15,'Engineering Mechanics and Strength of Materials':15,'Thermal Engineering and Refrigeration & Air-conditioning':20,'Fluid Mechanics & Machinery':15,'Material Science & Production Engineering':20,'Metrology and Automobile Engineering':15,'Industrial Management and CAD/CAM':20};
 const pool=[...SAME,...NEAR];let qs=[];for(const [s,n] of Object.entries(W)){const ps=shuffle(pool.filter(q=>q.subject===s));const fill=shuffle(PYQ.filter(q=>q.subject===s));qs.push(...ps.slice(0,n));if(ps.length<n)qs.push(...fill.slice(0,n-ps.length))}
 startQueue(shuffle(qs).slice(0,120),'JKSSB-level mock',true,120)}
window.jkHome=jkHome;
const _home=home;home=function(){_home();try{const pt=document.querySelector('.primary-tools');if(pt&&!document.querySelector('#jkx')){pt.insertAdjacentHTML('afterbegin',`<button class='btn hy-btn' id='jkx' style='background:var(--ink);color:var(--paper)'>JKSSB Exact <span class='hy-sub'>Syllabus map · ${PAPERS.length} real papers · ${SAME.length+NEAR.length} JKSSB-level questions</span></button>`);document.querySelector('#jkx').onclick=jkHome}}catch(e){console.error(e)}};
if(state.mode==='home')home();
})();
