/* ===== V8 study features: notes & answer corrections, numerical/theory, chapters, exam plan, heatmap, revision sheets ===== */
(function(){
const QBYID=new Map(ALLQ.map(q=>[q.id,q]));
const LET=i=>String.fromCharCode(65+i);
const today=()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
const jget=(k,d)=>{try{const v=JSON.parse(LS.get(k)||'null');return v==null?d:v}catch(e){return d}};
const jset=(k,v)=>LS.set(k,JSON.stringify(v));
const isNum=q=>q.k==='n';
window.isNum=isNum;

/* ---------- notes & corrections ---------- */
const getNotes=()=>jget('jkssb-notes',{});
function applyCorrections(){const n=getNotes();for(const q of ALLQ){if(q.ans0!=null&&!(n[q.id]&&n[q.id].a)){q.ans=q.ans0;delete q.ans0}}
 for(const [id,r] of Object.entries(n)){const q=QBYID.get(+id);if(!q||!r||!r.a)continue;if(q.ans0==null)q.ans0=q.ans;q.ans=r.a}}
function setNote(q,patch){const n=getNotes();const cur=n[q.id]||{n:'',a:0};const nx={...cur,...patch,at:Date.now()};
 if(nx.a&&nx.a===(q.ans0!=null?q.ans0:q.ans))nx.a=0;
 n[q.id]=nx;jset('jkssb-notes',n);applyCorrections();notesMark()}
const hasNote=r=>r&&((r.n&&r.n.trim())||r.a);

function noteBoxHTML(q){const r=getNotes()[q.id]||{};const orig=q.ans0!=null?q.ans0:q.ans;
 const corr=r.a?`<p class='corr'><b>Your correction is applied:</b> ${LET(ordOf(q).indexOf(r.a-1))}. ${esc(q.opts[r.a-1])} <span class='muted'>(source key: ${LET(ordOf(q).indexOf(orig-1))}. ${esc(q.opts[orig-1])})</span></p>`:'';
 const fixed=q.fix?`<p class='fixnote'>${esc(q.fix)}</p>`:'';
 return `<div class='notebox'>${fixed}${corr}${r.n&&r.n.trim()?`<div class='mynote'><b>My note</b><p>${esc(r.n)}</p></div>`:''}
 <div class='row nb-btns'><button class='btn secondary nb-edit'>${r.n&&r.n.trim()?'Edit note':'Add note'}</button><button class='btn secondary nb-key'>${r.a?'Change correction':'Wrong answer?'}</button></div>
 <div class='nb-form' hidden><textarea rows='3' maxlength='2000' placeholder='Formula, trick, why the key is wrong…'></textarea><div class='row'><button class='btn secondary nb-cancel'>Cancel</button><button class='btn nb-save'>Save note</button></div></div>
 <div class='nb-kform' hidden><p class='small muted' style='margin:6px 0'>Which option is actually correct? The app will use your answer on all your devices, and you can send me your corrections from My Notes.</p><div class='nb-opts'>${ordOf(q).map((oi,di)=>`<button class='btn secondary nb-pick' data-a='${oi+1}'>${LET(di)}. ${esc(q.opts[oi])}</button>`).join('')}</div><div class='row'>${r.a?`<button class='btn secondary nb-reset'>Restore source answer</button>`:''}<button class='btn secondary nb-kcancel'>Cancel</button></div></div></div>`}
function wireNoteBox(q,root,rerender){const b=root.querySelector('.notebox');if(!b)return;const f=b.querySelector('.nb-form'),kf=b.querySelector('.nb-kform'),ta=f.querySelector('textarea');
 b.querySelector('.nb-edit').onclick=()=>{kf.hidden=true;f.hidden=false;ta.value=(getNotes()[q.id]||{}).n||'';ta.focus()};
 b.querySelector('.nb-cancel').onclick=()=>{f.hidden=true};
 b.querySelector('.nb-save').onclick=()=>{setNote(q,{n:ta.value.slice(0,2000)});note(ta.value.trim()?'Note saved.':'Note removed.');rerender()};
 b.querySelector('.nb-key').onclick=()=>{f.hidden=true;kf.hidden=false};
 b.querySelector('.nb-kcancel').onclick=()=>{kf.hidden=true};
 b.querySelectorAll('.nb-pick').forEach(x=>x.onclick=()=>{setNote(q,{a:+x.dataset.a});note('Correction saved. This question now uses your answer.');rerender()});
 const rs=b.querySelector('.nb-reset');if(rs)rs.onclick=()=>{setNote(q,{a:0});note('Source answer restored.');rerender()}}

/* ---------- plan & daily counts ---------- */
const getPlan=()=>jget('jkssb-plan',{exam:'',target:100,at:0});
const getDaily=()=>jget('jkssb-daily',{});
function bumpDaily(){const d=getDaily(),t=today();d[t]=(d[t]||0)+1;jset('jkssb-daily',d);notesMark()}

/* ---------- sync of notes / plan / daily (same store as progress) ---------- */
let nTimer=null,nBusy=false;
function notesMark(){clearTimeout(nTimer);nTimer=setTimeout(notesSync,2500)}
async function notesSync(){if(typeof Sync==='undefined'||!Sync.db||nBusy)return;nBusy=true;try{
 const ref=Sync.db.doc(Sync.base+'/notes');const sn=await ref.get();const rem=sn.exists?(sn.data()||{}):{};
 const L=getNotes(),R=rem.notes||{};let changedL=false,changedR=false;
 for(const [id,r] of Object.entries(R)){const l=L[id];if(!l||(r.at||0)>(l.at||0)){L[id]=r;changedL=true}}
 for(const [id,l] of Object.entries(L)){const r=R[id];if(!r||(l.at||0)>(r.at||0))changedR=true}
 let P=getPlan();const RP=rem.plan;if(RP&&(RP.at||0)>(P.at||0)){P=RP;jset('jkssb-plan',P);changedL=true}else if(!RP||(P.at||0)>(RP.at||0))changedR=true;
 const D=getDaily(),RD=rem.daily||{};for(const [k,v] of Object.entries(RD)){if((D[k]||0)<v){D[k]=v;changedL=true}}for(const [k,v] of Object.entries(D)){if((RD[k]||0)<v)changedR=true}
 if(changedL){jset('jkssb-notes',L);jset('jkssb-daily',D);applyCorrections();if(state.mode==='home')home()}
 if(changedR){const keep={};const cut=Date.now()-120*86400000;for(const [k,v] of Object.entries(D))if(new Date(k).getTime()>cut)keep[k]=v;
  await ref.set({notes:L,plan:P,daily:keep})}
}catch(e){}finally{nBusy=false}}
let tries=0;const poll=setInterval(()=>{tries++;if(typeof Sync!=='undefined'&&Sync.db){clearInterval(poll);notesSync()}else if(tries>40)clearInterval(poll)},1500);
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')notesSync()});
window.notesSync=notesSync;
if(typeof initSync==='function'){const _init=initSync;initSync=async function(...a){const r=await _init(...a);notesSync();return r}}

/* ---------- hooks into the core app ---------- */
const _save=save;save=function(q,ok){_save(q,ok);bumpDaily()};
const _renderQ=renderQ;renderQ=function(){_renderQ();const q=state.queue&&state.queue[state.idx];if(!q||state.mode!=='quiz')return;
 const ans=document.querySelector('.answer');if(ans&&!state.testMode&&state.checked){ans.insertAdjacentHTML('beforeend',noteBoxHTML(q));wireNoteBox(q,ans,()=>renderQ())}
 if(!state.testMode&&!state.checked&&state.queue.length-state.idx>1){const row=document.querySelector('.row.actions');if(row){row.insertAdjacentHTML('afterbegin',"<button class='btn secondary' id='skipq'>Skip</button>");
  document.querySelector('#skipq').onclick=()=>{const cur=state.queue.splice(state.idx,1)[0];state.queue.push(cur);state.selected=null;delete state.answers[cur.id];state.skipped=(state.skipped||0)+1;note('Skipped. It comes back at the end of this set.');renderQ()}}}
 const meta=document.querySelector('.quiz .meta');if(meta){if(isNum(q))meta.insertAdjacentHTML('beforeend'," · <span class='tag num'>Numerical</span>");if(q.fmt)meta.insertAdjacentHTML('beforeend'," · <span class='tag num'>"+(q.fmt==='ar'?'Assertion–Reason':'Match')+"</span>");const r=getNotes()[q.id];if(hasNote(r))meta.insertAdjacentHTML('beforeend'," · <span class='tag'>✎ Noted</span>")}};
const _review=review;review=function(){_review();document.querySelectorAll('.card.review').forEach((el,i)=>{const q=state.queue[i];el.insertAdjacentHTML('beforeend',noteBoxHTML(q));wireNoteBox(q,el,()=>{const y=scrollY;review();scrollTo(0,y)})})};

if(typeof jkssbMock==='function'){const _mock=jkssbMock;jkssbMock=function(){_mock();if(state.mode!=='quiz'||!state.testMode)return;const fm=shuffle(QS.filter(q=>q.fmt));if(!fm.length)return;const want=Math.min(10,fm.length);let k=0;
 for(const i of shuffle([...state.queue.keys()])){if(k>=want)break;const q=state.queue[i];if(q.fmt)continue;const j=fm.findIndex(f=>f.subject===q.subject&&!state.queue.includes(f));if(j>=0){state.queue[i]=fm.splice(j,1)[0];k++}}renderQ()}}
/* ---------- selection helpers ---------- */
function weights(){const w={};for(const s of subjects)w[s]=0;for(const q of ALLQ)if(isJKSSB(q)&&w[q.subject]!=null)w[q.subject]++;const t=Object.values(w).reduce((a,b)=>a+b,0)||1;for(const s in w)w[s]=w[s]/t;return w}
function priorityPick(pool,n){const p=getProgress(),now=Date.now();const sc=q=>{const r=p[q.id];let s=Math.random()*10;if(!r){s+=40;if(q.hy)s+=25+q.hy*3;if(isJKSSB(q))s+=20;if(q.scope!=='extended')s+=10}else{if(r.mastery==='mastered')s-=60;if((r.wrong||0)>0&&!r.lastOk)s+=55;else if((r.wrong||0)>0)s+=30;if(now-(r.lastAt||0)>4*86400000)s+=15}return s};
 return pool.map(q=>[sc(q),q]).sort((a,b)=>b[0]-a[0]).slice(0,n).map(x=>x[1])}
function chapterStats(qs){const p=getProgress();let att=0,a=0,c=0;for(const q of qs){const r=p[q.id];if(!r)continue;att++;a+=r.attempts||1;c+=r.correct||0}return{n:qs.length,att,acc:a?Math.round(c/a*100):null,attempts:a}}
const heat=acc=>acc==null?'h0':acc<50?'h1':acc<70?'h2':'h3';

/* ---------- home additions ---------- */
const _home=home;home=function(){_home();try{injectHome()}catch(e){console.error(e)}};
function planCardHTML(){const P=getPlan(),d=getDaily()[today()]||0;
 if(!P.exam)return `<div class='card plan'><div class='row'><div><b>Exam countdown</b><p class='muted small' style='margin:2px 0 0'>Set your exam date to get a daily target and a plan weighted like the JKSSB paper.</p></div><button class='btn' id='plan-set'>Set exam date</button></div></div>`;
 const days=Math.max(0,Math.ceil((new Date(P.exam+'T09:00:00')-Date.now())/86400000));const pct=Math.min(100,Math.round(d/P.target*100));
 const p=getProgress();const coreUnseen=QS.filter(q=>q.scope!=='extended'&&!p[q.id]).length;const pace=days?Math.ceil(coreUnseen/days):coreUnseen;
 return `<div class='card plan'><div class='row'><div><span class='big'>${days}</span> <b>day${days===1?'':'s'} to the exam</b><p class='muted small' style='margin:2px 0 0'>${new Date(P.exam).toLocaleDateString(undefined,{day:'numeric',month:'long',year:'numeric'})} · <a href='#' id='plan-edit'>change</a></p></div><button class='btn' id='plan-go'>${d>=P.target?'Extra practice':"Today's plan"}</button></div>
 <div class='bar'><span style='width:${pct}%'></span></div><p class='small' style='margin:6px 0 0'><b>${d} / ${P.target}</b> questions today${d>=P.target?' · target done ✓':''}. <span class='muted'>${coreUnseen.toLocaleString()} core questions unseen — about ${pace}/day covers them all.</span></p></div>`}
function injectHome(){const wrap=document.querySelector('#app .wrap');if(!wrap)return;const hero=wrap.querySelector('.hero');
 hero.querySelector('.pill').textContent='Personal study app · V8';
 hero.insertAdjacentHTML('afterend',planCardHTML());
 const nN=QS.filter(isNum).length,nT=QS.length-nN,notes=Object.values(getNotes()).filter(hasNote).length;
 const nF=QS.filter(q=>q.fmt).length;const pt=wrap.querySelector('.primary-tools');pt.insertAdjacentHTML('beforeend',`<button class='btn' id='numq'>Numerical <span class='hy-sub'>${nN.toLocaleString()}</span></button><button class='btn' id='thq'>Theory <span class='hy-sub'>${nT.toLocaleString()}</span></button>${nF?`<button class='btn hy-btn' id='fmtq'>Assertion–Reason &amp; Match <span class='hy-sub'>${nF} questions in JKSSB's special formats</span></button>`:''}`);
 const tb=wrap.querySelector('.study-tools .toolbar');tb.insertAdjacentHTML('afterbegin',`<button class='btn secondary' id='mynotes'>My Notes${notes?' ('+notes+')':''}</button><button class='btn secondary' id='heatmap'>Chapter heatmap</button>`);
 const P=getPlan();
 const set=document.querySelector('#plan-set')||document.querySelector('#plan-edit');if(set)set.onclick=e=>{e.preventDefault();planDialog()};
 const go=document.querySelector('#plan-go');if(go)go.onclick=todaysPlan;
 document.querySelector('#numq').onclick=()=>typeDialog(true);document.querySelector('#thq').onclick=()=>typeDialog(false);
 const fq=document.querySelector('#fmtq');if(fq)fq.onclick=()=>{const f=QS.filter(q=>q.fmt);startQueue(shuffle(priorityPick(f,30)),'Assertion–Reason & Match',false)};
 document.querySelector('#mynotes').onclick=notesPage;document.querySelector('#heatmap').onclick=heatmapPage;
 wrap.querySelectorAll('.grid [data-s]').forEach(x=>x.onclick=()=>subjectPage(x.dataset.s))}
function planDialog(){const P=getPlan();const d=document.createElement('div');d.className='dlg-back';
 d.innerHTML=`<form class='dlg form'><h3 style='margin:0'>Exam plan</h3><label>Exam date<input type='date' name='e' required value='${P.exam||''}'></label><label>Questions per day<select name='t'>${[50,75,100,150,200,250,300].map(v=>`<option ${v===P.target?'selected':''}>${v}</option>`).join('')}</select></label><div class='row' style='justify-content:flex-end'><button type='button' class='btn secondary' data-x>Cancel</button><button class='btn'>Save</button></div></form>`;
 document.body.appendChild(d);d.querySelector('[data-x]').onclick=()=>d.remove();
 d.querySelector('form').onsubmit=e=>{e.preventDefault();const f=e.target;jset('jkssb-plan',{exam:f.e.value,target:+f.t.value,at:Date.now()});notesMark();d.remove();home()}}
function todaysPlan(){const P=getPlan(),d=getDaily()[today()]||0;const n=Math.max(20,Math.min(60,P.target-d>0?P.target-d:30));const w=weights();let qs=[];
 for(const s of subjects){const k=Math.max(1,Math.round(n*w[s]));qs.push(...priorityPick(QS.filter(q=>q.subject===s),k))}
 startQueue(shuffle(qs).slice(0,n),"Today's plan",false)}
function typeDialog(num){const qs=QS.filter(q=>isNum(q)===num);const d=document.createElement('div');d.className='dlg-back';
 d.innerHTML=`<div class='dlg form'><h3 style='margin:0'>${num?'Numerical':'Theory'} practice</h3><label>Subject<select id='td-s'><option value='ALL'>All subjects (${qs.length})</option>${subjects.map(s=>`<option value="${esc(s)}">${esc(s)} (${qs.filter(q=>q.subject===s).length})</option>`).join('')}</select></label><label>Questions<select id='td-n'><option>20</option><option selected>30</option><option>50</option></select></label><div class='row' style='justify-content:flex-end'><button class='btn secondary' data-x>Cancel</button><button class='btn' id='td-go'>Start</button></div></div>`;
 document.body.appendChild(d);d.querySelector('[data-x]').onclick=()=>d.remove();
 d.querySelector('#td-go').onclick=()=>{const s=d.querySelector('#td-s').value,n=+d.querySelector('#td-n').value;const pool=s==='ALL'?qs:qs.filter(q=>q.subject===s);d.remove();startQueue(shuffle(priorityPick(pool,n)),(num?'Numerical':'Theory')+(s==='ALL'?'':' · '+s),false)}}

/* ---------- subject → chapter pages ---------- */
subjectPage=function(s){stopTimer();state.mode='subject';const qs=QS.filter(q=>q.subject===s),topics=[...new Set(qs.map(q=>q.topic))].sort((a,b)=>qs.filter(q=>q.topic===b).length-qs.filter(q=>q.topic===a).length);const st=chapterStats(qs);
 app.innerHTML=`<div class='wrap'><div class='row'><button class='btn secondary' id='home'>← Home</button><span class='pill'>${qs.length.toLocaleString()} questions</span></div><h1>${esc(s)}</h1><p class='muted'>${st.att.toLocaleString()} attempted${st.acc!=null?' · '+st.acc+'% accuracy':''} · ${qs.filter(isNum).length} numerical · ${qs.filter(q=>!isNum(q)).length} theory</p>
 <div class='toolbar'><button class='btn' id='sec-mock'>Sectional mock · 30 Q / 30 min</button><button class='btn secondary' id='all'>Practice all</button><button class='btn secondary' id='s-num'>Numerical</button><button class='btn secondary' id='s-th'>Theory</button></div>
 <h2>Chapters</h2><div class='grid'>${topics.map(t=>{const tq=qs.filter(q=>q.topic===t),c=chapterStats(tq);return `<button class='card subject chap ${heat(c.acc)}' data-t="${esc(t)}"><b>${esc(t)}</b><span class='muted'>${tq.length} Q · ${tq.filter(isNum).length} numerical · ${c.att?c.acc+'% · '+c.att+' seen':'not started'}${window.SHEETS&&SHEETS[t]?' · 📄 sheet':''}</span></button>`}).join('')}</div></div>`;
 document.querySelector('#home').onclick=home;document.querySelector('#all').onclick=()=>startQueue(shuffle(qs),s,false);
 document.querySelector('#s-num').onclick=()=>startQueue(shuffle(priorityPick(qs.filter(isNum),30)),s+' · Numerical',false);
 document.querySelector('#s-th').onclick=()=>startQueue(shuffle(priorityPick(qs.filter(q=>!isNum(q)),30)),s+' · Theory',false);
 document.querySelector('#sec-mock').onclick=()=>{const w={};for(const t of topics)w[t]=qs.filter(q=>q.topic===t).length;let pick=[];for(const t of topics){const k=Math.round(30*w[t]/qs.length);pick.push(...shuffle(qs.filter(q=>q.topic===t)).slice(0,k))}
  const rest=shuffle(qs.filter(q=>!pick.includes(q)));while(pick.length<30&&rest.length)pick.push(rest.pop());startQueue(shuffle(pick.slice(0,30)),'Sectional mock · '+s,true,30)};
 document.querySelectorAll('[data-t]').forEach(x=>x.onclick=()=>chapterPage(s,x.dataset.t))};
function sheetHTML(t){const raw=window.SHEETS&&SHEETS[t];if(!raw)return '';const lines=raw.split('\n');let h='',inl=false;
 for(let l of lines){l=l.trimEnd();if(!l.trim()){if(inl){h+='</ul>';inl=false}continue}
  const fmt=x=>esc(x).replace(/\*\*(.+?)\*\*/g,'<b>$1</b>');
  if(/^#{1,3}\s/.test(l)){if(inl){h+='</ul>';inl=false}h+=`<h4>${fmt(l.replace(/^#+\s*/,''))}</h4>`}
  else if(/^\s*[-•*]\s/.test(l)){if(!inl){h+='<ul>';inl=true}h+=`<li>${fmt(l.replace(/^\s*[-•*]\s*/,''))}</li>`}
  else{if(inl){h+='</ul>';inl=false}h+=`<p>${fmt(l)}</p>`}}
 if(inl)h+='</ul>';return `<details class='card sheet'><summary><b>📄 Revision sheet</b> <span class='muted small'>formulas · standard values · traps</span></summary><div class='sheet-body'>${h}</div></details>`}
function chapterPage(s,t){stopTimer();state.mode='chapter';const qs=QS.filter(q=>q.subject===s&&q.topic===t),p=getProgress(),c=chapterStats(qs);
 const nums=qs.filter(isNum),th=qs.filter(q=>!isNum(q)),unseen=qs.filter(q=>!p[q.id]),wrong=qs.filter(q=>p[q.id]&&(p[q.id].wrong||0)>0&&p[q.id].mastery!=='mastered'),pyq=qs.filter(isJKSSB),noted=qs.filter(q=>hasNote(getNotes()[q.id]));
 const n=Math.min(25,qs.length);
 app.innerHTML=`<div class='wrap'><div class='row'><button class='btn secondary' id='back'>← ${esc(s)}</button><span class='pill'>${qs.length} questions</span></div><h1>${esc(t)}</h1><p class='muted'>${c.att} of ${qs.length} seen${c.acc!=null?' · '+c.acc+'% accuracy':''}</p>${sheetHTML(t)}
 <div class='toolbar primary-tools'><button class='btn hy-btn' id='c-test'>Chapter test · ${n} Q / ${n} min <span class='hy-sub'>negative marking, answers at the end</span></button>
 <button class='btn' data-k='all'>All <span class='hy-sub'>${qs.length}</span></button><button class='btn' data-k='unseen'>Unseen <span class='hy-sub'>${unseen.length}</span></button>
 <button class='btn secondary' data-k='num'>Numerical <span class='hy-sub'>${nums.length}</span></button><button class='btn secondary' data-k='th'>Theory <span class='hy-sub'>${th.length}</span></button>
 <button class='btn secondary' data-k='wrong'>My wrong <span class='hy-sub'>${wrong.length}</span></button><button class='btn secondary' data-k='pyq'>JKSSB PYQs <span class='hy-sub'>${pyq.length}</span></button>
 ${qs.some(q=>q.fmt)?`<button class='btn secondary' data-k='fmt'>A–R &amp; Match <span class='hy-sub'>${qs.filter(q=>q.fmt).length}</span></button>`:''}${noted.length?`<button class='btn secondary' data-k='noted'>With my notes <span class='hy-sub'>${noted.length}</span></button>`:''}</div></div>`;
 document.querySelector('#back').onclick=()=>subjectPage(s);
 const sets={fmt:shuffle(qs.filter(q=>q.fmt)),all:priorityPick(qs,qs.length),unseen:shuffle(unseen),num:priorityPick(nums,nums.length),th:priorityPick(th,th.length),wrong,pyq:shuffle(pyq),noted};
 document.querySelectorAll('[data-k]').forEach(b=>b.onclick=()=>{const k=b.dataset.k;startQueue(sets[k].slice(0,k==='all'?50:100),t+' · '+b.firstChild.textContent.trim(),false)});
 document.querySelector('#c-test').onclick=()=>startQueue(shuffle(priorityPick(qs,n)),'Chapter test · '+t,true,n)}
window.chapterPage=chapterPage;

/* ---------- heatmap ---------- */
function heatmapPage(){stopTimer();state.mode='heatmap';
 app.innerHTML=`<div class='wrap'><div class='row'><button class='btn secondary' id='home'>← Home</button><span class='pill'>Chapter heatmap</span></div><h1>Where you stand</h1><p class='muted'>Accuracy per chapter. <span class='key h1'>below 50%</span> <span class='key h2'>50–69%</span> <span class='key h3'>70%+</span> <span class='key h0'>not started</span> · Tap a chapter to practise it.</p>
 ${subjects.map(s=>{const qs=QS.filter(q=>q.subject===s);const ts=[...new Set(qs.map(q=>q.topic))];const w=Math.round(weights()[s]*100);return `<h2>${esc(s)} <span class='muted small'>· ~${w}% of JKSSB papers</span></h2><div class='heat'>${ts.map(t=>{const c=chapterStats(qs.filter(q=>q.topic===t));return `<button class='hc ${heat(c.acc)}' data-s="${esc(s)}" data-t="${esc(t)}"><span>${esc(t)}</span><b>${c.acc!=null?c.acc+'%':'–'}</b><small>${c.att}/${c.n}</small></button>`}).join('')}</div>`}).join('')}</div>`;
 document.querySelector('#home').onclick=home;document.querySelectorAll('.hc').forEach(x=>x.onclick=()=>chapterPage(x.dataset.s,x.dataset.t))}

/* ---------- my notes ---------- */
function notesPage(){stopTimer();state.mode='notes';const N=getNotes();const items=Object.entries(N).filter(([id,r])=>hasNote(r)&&QBYID.get(+id)).sort((a,b)=>(b[1].at||0)-(a[1].at||0));const corr=items.filter(([id,r])=>r.a);
 app.innerHTML=`<div class='wrap'><div class='row'><button class='btn secondary' id='home'>← Home</button><span class='pill'>${items.length} noted · ${corr.length} corrections</span></div><h1>My Notes</h1>
 <div class='toolbar'>${items.length?`<button class='btn' id='n-prac'>Practise these</button>`:''}${corr.length?`<button class='btn secondary' id='n-copy'>Send corrections to Claude</button>`:''}</div>
 ${items.length?items.map(([id,r])=>{const q=QBYID.get(+id);const orig=q.ans0!=null?q.ans0:q.ans;return `<div class='card review'><div class='meta'>${esc(q.subject)} · ${esc(q.topic)} · #${q.id}</div><h3>${esc(q.q)}</h3>${r.a?`<p><b>Your answer:</b> ${esc(q.opts[r.a-1])} <span class='muted'>(source said: ${esc(q.opts[orig-1])})</span></p>`:`<p><b>Answer:</b> ${esc(q.opts[q.ans-1])}</p>`}${r.n&&r.n.trim()?`<div class='mynote'><p>${esc(r.n)}</p></div>`:''}</div>`}).join(''):`<div class='card'><b>No notes yet.</b><p class='muted'>After you check an answer, use <b>Add note</b> or <b>Wrong answer?</b> under the explanation.</p></div>`}</div>`;
 document.querySelector('#home').onclick=home;
 const pr=document.querySelector('#n-prac');if(pr)pr.onclick=()=>startQueue(items.map(([id])=>QBYID.get(+id)),'My noted questions',false);
 const cp=document.querySelector('#n-copy');if(cp)cp.onclick=()=>{const txt='JKSSB app corrections:\n'+corr.map(([id,r])=>{const q=QBYID.get(+id);const orig=q.ans0!=null?q.ans0:q.ans;return `#${id} | ${q.q.slice(0,90)} | source: ${q.opts[orig-1]} | mine: ${q.opts[r.a-1]}${r.n?' | note: '+r.n.replace(/\s+/g,' ').slice(0,200):''}`}).join('\n');
  const d=document.createElement('div');d.className='dlg-back';d.innerHTML=`<div class='dlg form'><h3 style='margin:0'>Send corrections</h3><p class='small muted' style='margin:0;font-size:14px'>Copy this and paste it into our Claude chat. I'll fix these in the question bank for the next update.</p><textarea rows='8' readonly></textarea><div class='row' style='justify-content:flex-end'><button class='btn secondary' data-x>Close</button><button class='btn' data-c>Copy</button></div></div>`;
  document.body.appendChild(d);const ta=d.querySelector('textarea');ta.value=txt;ta.select();d.querySelector('[data-x]').onclick=()=>d.remove();
  d.querySelector('[data-c]').onclick=async()=>{try{await navigator.clipboard.writeText(txt);note('Copied.')}catch(e){ta.select();try{document.execCommand('copy');note('Copied.')}catch(_){note('Select the text and copy it.')}}}}}

applyCorrections();
if(state.mode==='home')home();
})();
